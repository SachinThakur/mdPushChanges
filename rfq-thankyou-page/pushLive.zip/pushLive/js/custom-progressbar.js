jQuery(document).ready(function() {
jQuery('#progressBar').LineProgressbar({
percentage:40,
radius: '12px',
height: '44px',
});
jQuery('#progressBar1').LineProgressbar({
percentage:64,
radius: '12px',
height: '44px',
});
});